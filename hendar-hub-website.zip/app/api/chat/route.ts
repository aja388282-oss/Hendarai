import type { NextRequest } from "next/server"

export const maxDuration = 300 // 5 minutes for chat

export async function POST(req: NextRequest) {
  try {
    const { messages, systemPrompt } = await req.json()

    // Prepare messages for API
    const apiMessages = [
      {
        role: "system",
        content:
          systemPrompt ||
          "You are Hendar Hub AI, a professional, smart, friendly, and helpful AI assistant. You are an expert in Lua, Delta Executor, web development, math, and coding help. When generating Lua code, format it properly and indicate it should be displayed in a code textbox.",
      },
      ...messages.map((msg: any) => ({
        role: msg.role,
        content: Array.isArray(msg.content) ? msg.content : [{ type: "text", text: msg.content }],
      })),
    ]

    const response = await fetch("https://llm.blackbox.ai/chat/completions", {
      method: "POST",
      headers: {
        userEmail: "aja388282@gmail.com",
        "Content-Type": "application/json",
        Authorization: "Bearer xxx",
      },
      body: JSON.stringify({
        model: "custom/blackbox-ai-chat",
        messages: apiMessages,
        stream: true,
      }),
      signal: req.signal,
    })

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`)
    }

    // Stream the response back to client
    return new Response(response.body, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    })
  } catch (error) {
    console.error("[v0] Chat API error:", error)
    return new Response(JSON.stringify({ error: "Failed to get AI response" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}
