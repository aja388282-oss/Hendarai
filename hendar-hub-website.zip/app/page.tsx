"use client"

import { useState, useEffect } from "react"
import { AuthScreen } from "@/components/auth-screen"
import { Sidebar } from "@/components/sidebar"
import { ChatInterface } from "@/components/chat-interface"
import { ProfilePanel } from "@/components/profile-panel"
import { getCurrentUser, checkAndRefillLimit } from "@/lib/auth"
import { getProjects, createProject, getActiveProjectId, setActiveProjectId, saveProject } from "@/lib/projects"
import type { User, Project, AppSettings } from "@/types"
import { translations } from "@/lib/translations"

export default function HomePage() {
  const [user, setUser] = useState<User | null>(null)
  const [projects, setProjects] = useState<Project[]>([])
  const [activeProject, setActiveProject] = useState<Project | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [profileOpen, setProfileOpen] = useState(false)
  const [settings, setSettings] = useState<AppSettings>({
    language: "en",
    ttsEnabled: false,
    ttsVoice: "female",
    ttsSpeed: 1.0,
  })
  const [isLoading, setIsLoading] = useState(true)

  const t = translations[settings.language]

  // Load user and projects on mount
  useEffect(() => {
    const currentUser = getCurrentUser()
    if (currentUser) {
      const updatedUser = checkAndRefillLimit(currentUser)
      setUser(updatedUser)
      loadUserProjects(updatedUser.id)
    }
    setIsLoading(false)

    // Load settings
    const savedSettings = localStorage.getItem("hendar_hub_settings")
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings))
    }
  }, [])

  const loadUserProjects = (userId: string) => {
    const userProjects = getProjects(userId)
    setProjects(userProjects)

    // Load active project or create new one
    const activeId = getActiveProjectId()
    let active = userProjects.find((p) => p.id === activeId)

    if (!active && userProjects.length > 0) {
      active = userProjects[0]
      setActiveProjectId(active.id)
    }

    if (!active) {
      active = createProject(userId)
      setProjects([active])
    }

    setActiveProject(active)
  }

  const handleAuthSuccess = () => {
    const currentUser = getCurrentUser()
    if (currentUser) {
      setUser(currentUser)
      loadUserProjects(currentUser.id)
    }
  }

  const handleNewProject = () => {
    if (!user) return
    const newProject = createProject(user.id)
    setProjects((prev) => [newProject, ...prev])
    setActiveProject(newProject)
    setSidebarOpen(false)
  }

  const handleProjectSelect = (projectId: string) => {
    const project = projects.find((p) => p.id === projectId)
    if (project) {
      setActiveProject(project)
      setActiveProjectId(projectId)
    }
    setSidebarOpen(false)
  }

  const handleMessagesUpdate = (messages: any[]) => {
    if (!activeProject) return

    const updatedProject = {
      ...activeProject,
      messages,
      updatedAt: Date.now(),
    }

    setActiveProject(updatedProject)
    saveProject(updatedProject)

    // Update in projects list
    setProjects((prev) => prev.map((p) => (p.id === updatedProject.id ? updatedProject : p)))
  }

  const handleUserUpdate = (updatedUser: User) => {
    setUser(updatedUser)
  }

  const handleLanguageChange = (lang: "en" | "id") => {
    const newSettings = { ...settings, language: lang }
    setSettings(newSettings)
    localStorage.setItem("hendar_hub_settings", JSON.stringify(newSettings))
  }

  const handleTtsToggle = () => {
    const newSettings = { ...settings, ttsEnabled: !settings.ttsEnabled }
    setSettings(newSettings)
    localStorage.setItem("hendar_hub_settings", JSON.stringify(newSettings))
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-950">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-amber-500"></div>
      </div>
    )
  }

  if (!user) {
    return <AuthScreen onAuthSuccess={handleAuthSuccess} t={t} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950">
      <Sidebar
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        projects={projects}
        activeProjectId={activeProject?.id || null}
        onProjectSelect={handleProjectSelect}
        onNewProject={handleNewProject}
        t={t}
      />

      <ProfilePanel
        isOpen={profileOpen}
        onToggle={() => setProfileOpen(!profileOpen)}
        user={user}
        onUserUpdate={handleUserUpdate}
        onLogout={() => setUser(null)}
        t={t}
        language={settings.language}
        onLanguageChange={handleLanguageChange}
        ttsEnabled={settings.ttsEnabled}
        onTtsToggle={handleTtsToggle}
      />

      <main className="h-screen">
        {activeProject && (
          <ChatInterface
            projectId={activeProject.id}
            messages={activeProject.messages}
            onMessagesUpdate={handleMessagesUpdate}
            t={t}
            ttsEnabled={settings.ttsEnabled}
          />
        )}
      </main>
    </div>
  )
}
