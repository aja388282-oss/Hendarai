export type UserRole = "user" | "developer" | "owner"
export type UserPlan = "free" | "junior" | "basic" | "premium" | "elite" | "super"
export type UserStatus = "active" | "disabled" | "banned"

export interface User {
  id: string
  email: string
  password: string
  username: string
  role: UserRole
  plan: UserPlan
  status: UserStatus
  avatar?: string
  messageLimit: number
  limitLevel: number
  lastRefillTime?: number
  expirationDate?: number
  createdAt: number
}

export interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: number
  images?: string[]
  isCode?: boolean
  language?: string
}

export interface Project {
  id: string
  userId: string
  name: string
  messages: Message[]
  createdAt: number
  updatedAt: number
}

export interface RedeemCode {
  code: string
  email?: string
  role: UserRole
  plan: UserPlan
  limitAmount: number
  limitLevel: number
  expirationDays?: number
  used: boolean
  usedBy?: string
  createdAt: number
}

export interface AppSettings {
  language: "en" | "id"
  ttsEnabled: boolean
  ttsVoice: "male" | "female"
  ttsSpeed: number
}
