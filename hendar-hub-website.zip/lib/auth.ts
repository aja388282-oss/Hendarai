import type { User, UserPlan } from "@/types"

const USERS_KEY = "hendar_hub_users"
const CURRENT_USER_KEY = "hendar_hub_current_user"

export function getUsers(): User[] {
  if (typeof window === "undefined") return []
  const data = localStorage.getItem(USERS_KEY)
  return data ? JSON.parse(data) : []
}

export function saveUsers(users: User[]) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users))
}

export function getCurrentUser(): User | null {
  if (typeof window === "undefined") return null
  const data = localStorage.getItem(CURRENT_USER_KEY)
  return data ? JSON.parse(data) : null
}

export function setCurrentUser(user: User | null) {
  if (user) {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user))
  } else {
    localStorage.removeItem(CURRENT_USER_KEY)
  }
}

export function login(email: string, password: string): User | null {
  const users = getUsers()
  const user = users.find((u) => u.email === email && u.password === password)

  if (!user) return null
  if (user.status === "disabled" || user.status === "banned") return null

  // Check expiration
  if (user.expirationDate && user.expirationDate < Date.now()) {
    user.plan = "free"
    user.messageLimit = 10
    user.limitLevel = 1
    user.expirationDate = undefined
    saveUsers(users)
  }

  setCurrentUser(user)
  return user
}

export function signup(email: string, password: string, username: string): User | null {
  const users = getUsers()

  if (users.find((u) => u.email === email)) {
    return null // Email already exists
  }

  const newUser: User = {
    id: crypto.randomUUID(),
    email,
    password,
    username,
    role: "user",
    plan: "free",
    status: "active",
    messageLimit: 10,
    limitLevel: 1,
    createdAt: Date.now(),
  }

  users.push(newUser)
  saveUsers(users)
  setCurrentUser(newUser)

  return newUser
}

export function logout() {
  setCurrentUser(null)
}

export function updateUser(userId: string, updates: Partial<User>) {
  const users = getUsers()
  const index = users.findIndex((u) => u.id === userId)

  if (index !== -1) {
    users[index] = { ...users[index], ...updates }
    saveUsers(users)

    // Update current user if it's the same
    const currentUser = getCurrentUser()
    if (currentUser && currentUser.id === userId) {
      setCurrentUser(users[index])
    }
  }
}

export function checkAndRefillLimit(user: User): User {
  const REFILL_COOLDOWN = 3 * 60 * 60 * 1000 // 3 hours

  if (user.messageLimit === 0 && user.lastRefillTime) {
    const timeSinceRefill = Date.now() - user.lastRefillTime

    if (timeSinceRefill >= REFILL_COOLDOWN) {
      const maxLimit = getMaxLimit(user.plan)
      user.messageLimit = maxLimit
      user.lastRefillTime = Date.now()
      updateUser(user.id, { messageLimit: user.messageLimit, lastRefillTime: user.lastRefillTime })
    }
  }

  return user
}

export function getMaxLimit(plan: UserPlan): number {
  const limits: Record<UserPlan, number> = {
    free: 10,
    junior: 50,
    basic: 100,
    premium: 200,
    elite: 500,
    super: -1, // Unlimited
  }
  return limits[plan]
}

export function decrementMessageLimit(userId: string) {
  const user = getCurrentUser()
  if (!user || user.id !== userId) return

  if (user.messageLimit > 0) {
    user.messageLimit -= 1
    if (user.messageLimit === 0) {
      user.lastRefillTime = Date.now()
    }
    updateUser(userId, { messageLimit: user.messageLimit, lastRefillTime: user.lastRefillTime })
  }
}

// Initialize owner account
export function initializeOwnerAccount() {
  const users = getUsers()
  const ownerEmail = "collectorhenfi@gmail.com"

  if (!users.find((u) => u.email === ownerEmail)) {
    const owner: User = {
      id: crypto.randomUUID(),
      email: ownerEmail,
      password: "owner123", // Should be changed by owner
      username: "Owner",
      role: "owner",
      plan: "super",
      status: "active",
      messageLimit: -1, // Unlimited
      limitLevel: 999,
      createdAt: Date.now(),
    }
    users.push(owner)
    saveUsers(users)
  }
}
