import type { Project, Message } from "@/types"

const PROJECTS_KEY = "hendar_hub_projects"
const ACTIVE_PROJECT_KEY = "hendar_hub_active_project"

export function getProjects(userId: string): Project[] {
  if (typeof window === "undefined") return []
  const data = localStorage.getItem(PROJECTS_KEY)
  const allProjects: Project[] = data ? JSON.parse(data) : []
  return allProjects.filter((p) => p.userId === userId)
}

export function saveProject(project: Project) {
  const data = localStorage.getItem(PROJECTS_KEY)
  const projects: Project[] = data ? JSON.parse(data) : []

  const index = projects.findIndex((p) => p.id === project.id)
  if (index !== -1) {
    projects[index] = project
  } else {
    projects.push(project)
  }

  localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects))
}

export function deleteProject(projectId: string) {
  const data = localStorage.getItem(PROJECTS_KEY)
  const projects: Project[] = data ? JSON.parse(data) : []
  const filtered = projects.filter((p) => p.id !== projectId)
  localStorage.setItem(PROJECTS_KEY, JSON.stringify(filtered))

  // Clear active if deleted
  const activeId = getActiveProjectId()
  if (activeId === projectId) {
    setActiveProjectId(null)
  }
}

export function getActiveProjectId(): string | null {
  if (typeof window === "undefined") return null
  return localStorage.getItem(ACTIVE_PROJECT_KEY)
}

export function setActiveProjectId(projectId: string | null) {
  if (projectId) {
    localStorage.setItem(ACTIVE_PROJECT_KEY, projectId)
  } else {
    localStorage.removeItem(ACTIVE_PROJECT_KEY)
  }
}

export function createProject(userId: string, name?: string): Project {
  const project: Project = {
    id: crypto.randomUUID(),
    userId,
    name: name || `New Chat ${new Date().toLocaleDateString()}`,
    messages: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  }

  saveProject(project)
  setActiveProjectId(project.id)

  return project
}

export function addMessage(projectId: string, message: Message) {
  const data = localStorage.getItem(PROJECTS_KEY)
  const projects: Project[] = data ? JSON.parse(data) : []
  const project = projects.find((p) => p.id === projectId)

  if (project) {
    project.messages.push(message)
    project.updatedAt = Date.now()
    saveProject(project)
  }
}

export function clearProjectMessages(projectId: string) {
  const data = localStorage.getItem(PROJECTS_KEY)
  const projects: Project[] = data ? JSON.parse(data) : []
  const project = projects.find((p) => p.id === projectId)

  if (project) {
    project.messages = []
    project.updatedAt = Date.now()
    saveProject(project)
  }
}
