export const translations = {
  en: {
    // Auth
    signIn: "Sign In",
    signUp: "Sign Up",
    email: "Email",
    password: "Password",
    username: "Username",
    login: "Login",
    register: "Register",
    logout: "Logout",
    alreadyHaveAccount: "Already have an account?",
    dontHaveAccount: "Don't have an account?",

    // Main UI
    newChat: "New Chat",
    projects: "Projects",
    profile: "Profile",
    settings: "Settings",
    developer: "Developer",

    // Chat
    typeMessage: "Type your message...",
    send: "Send",
    copyCode: "Copy Code",
    copied: "Copied!",
    speaking: "Speaking...",

    // Profile
    role: "Role",
    plan: "Plan",
    messagesLeft: "Messages Left",
    unlimited: "Unlimited",
    upgradeLimit: "Upgrade Limit",
    upgradePlan: "Upgrade Plan",

    // Plans
    free: "Free",
    junior: "Junior",
    basic: "Basic",
    premium: "Premium",
    elite: "Elite",
    super: "Super",

    // Roles
    user: "User",
    developer: "Developer",
    owner: "Owner",

    // Actions
    rename: "Rename",
    delete: "Delete",
    clearChat: "Clear Chat",
    cancel: "Cancel",
    confirm: "Confirm",

    // Messages
    limitReached: "Message limit reached!",
    waitForRefill: "Wait 3 hours for auto-refill or upgrade your plan",
    upgradeToContinue: "Upgrade to continue chatting",

    // Developer Panel
    userManagement: "User Management",
    searchUser: "Search user by email...",
    changeRole: "Change Role",
    changePlan: "Change Plan",
    setLimit: "Set Limit",
    addLimit: "Add Limit",
    banUser: "Ban User",
    unbanUser: "Unban User",
    disableUser: "Disable User",
    enableUser: "Enable User",

    // Welcome
    welcomeTitle: "Welcome to Hendar Hub AI",
    welcomeSubtitle: "Smart AI for Code, Scripts, and Learning",
    startChatting: "Start Chatting",
  },
  id: {
    // Auth
    signIn: "Masuk",
    signUp: "Daftar",
    email: "Email",
    password: "Kata Sandi",
    username: "Nama Pengguna",
    login: "Masuk",
    register: "Daftar",
    logout: "Keluar",
    alreadyHaveAccount: "Sudah punya akun?",
    dontHaveAccount: "Belum punya akun?",

    // Main UI
    newChat: "Chat Baru",
    projects: "Proyek",
    profile: "Profil",
    settings: "Pengaturan",
    developer: "Developer",

    // Chat
    typeMessage: "Ketik pesan Anda...",
    send: "Kirim",
    copyCode: "Salin Kode",
    copied: "Tersalin!",
    speaking: "Berbicara...",

    // Profile
    role: "Peran",
    plan: "Paket",
    messagesLeft: "Sisa Pesan",
    unlimited: "Tak Terbatas",
    upgradeLimit: "Tingkatkan Batas",
    upgradePlan: "Tingkatkan Paket",

    // Plans
    free: "Gratis",
    junior: "Junior",
    basic: "Basic",
    premium: "Premium",
    elite: "Elite",
    super: "Super",

    // Roles
    user: "Pengguna",
    developer: "Developer",
    owner: "Pemilik",

    // Actions
    rename: "Ubah Nama",
    delete: "Hapus",
    clearChat: "Hapus Chat",
    cancel: "Batal",
    confirm: "Konfirmasi",

    // Messages
    limitReached: "Batas pesan tercapai!",
    waitForRefill: "Tunggu 3 jam untuk isi ulang otomatis atau tingkatkan paket Anda",
    upgradeToContinue: "Tingkatkan untuk melanjutkan chat",

    // Developer Panel
    userManagement: "Manajemen Pengguna",
    searchUser: "Cari pengguna dengan email...",
    changeRole: "Ubah Peran",
    changePlan: "Ubah Paket",
    setLimit: "Atur Batas",
    addLimit: "Tambah Batas",
    banUser: "Blokir Pengguna",
    unbanUser: "Buka Blokir",
    disableUser: "Nonaktifkan",
    enableUser: "Aktifkan",

    // Welcome
    welcomeTitle: "Selamat Datang di Hendar Hub AI",
    welcomeSubtitle: "AI Cerdas untuk Kode, Skrip, dan Pembelajaran",
    startChatting: "Mulai Chat",
  },
}

export type TranslationKey = keyof typeof translations.en
