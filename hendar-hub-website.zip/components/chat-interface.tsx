"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Crown, Send, ImageIcon, Mic, Volume2, Copy, Sparkles, StopCircle } from "lucide-react"
import type { Message } from "@/types"
import { getCurrentUser, decrementMessageLimit } from "@/lib/auth"
import { addMessage } from "@/lib/projects"
import { cn } from "@/lib/utils"

interface ChatInterfaceProps {
  projectId: string
  messages: Message[]
  onMessagesUpdate: (messages: Message[]) => void
  t: any
  ttsEnabled: boolean
}

export function ChatInterface({ projectId, messages, onMessagesUpdate, t, ttsEnabled }: ChatInterfaceProps) {
  const [input, setInput] = useState("")
  const [images, setImages] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const abortControllerRef = useRef<AbortController | null>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  const handleSend = async () => {
    if ((!input.trim() && images.length === 0) || isLoading) return

    const user = getCurrentUser()
    if (!user) return

    // Check message limit
    if (user.messageLimit === 0 && user.plan !== "super") {
      alert(t.limitReached + "\n" + t.waitForRefill)
      return
    }

    // Create user message
    const userMessage: Message = {
      id: crypto.randomUUID(),
      role: "user",
      content: input,
      timestamp: Date.now(),
      images: images.length > 0 ? [...images] : undefined,
    }

    const newMessages = [...messages, userMessage]
    onMessagesUpdate(newMessages)
    addMessage(projectId, userMessage)

    // Decrement limit
    if (user.plan !== "super") {
      decrementMessageLimit(user.id)
    }

    // Clear input
    setInput("")
    setImages([])
    setIsLoading(true)

    try {
      // Prepare messages for API
      const apiMessages = newMessages.map((msg) => {
        if (msg.images && msg.images.length > 0) {
          return {
            role: msg.role,
            content: [
              { type: "text", text: msg.content },
              ...msg.images.map((img) => ({
                type: "image_url",
                image_url: { url: img },
              })),
            ],
          }
        }
        return {
          role: msg.role,
          content: msg.content,
        }
      })

      abortControllerRef.current = new AbortController()

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: apiMessages }),
        signal: abortControllerRef.current.signal,
      })

      if (!response.ok) throw new Error("Failed to get response")

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let assistantText = ""

      const assistantMessage: Message = {
        id: crypto.randomUUID(),
        role: "assistant",
        content: "",
        timestamp: Date.now(),
      }

      const messagesWithAssistant = [...newMessages, assistantMessage]
      onMessagesUpdate(messagesWithAssistant)

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break

          const chunk = decoder.decode(value)
          const lines = chunk.split("\n")

          for (const line of lines) {
            if (line.startsWith("data: ")) {
              const data = line.slice(6)
              if (data === "[DONE]") continue

              try {
                const parsed = JSON.parse(data)
                const content = parsed.choices?.[0]?.delta?.content
                if (content) {
                  assistantText += content
                  assistantMessage.content = assistantText

                  // Check if it's Lua code
                  if (assistantText.includes("```lua") || assistantText.includes("-- Lua")) {
                    assistantMessage.isCode = true
                    assistantMessage.language = "lua"
                  }

                  onMessagesUpdate([...newMessages, { ...assistantMessage }])
                }
              } catch (e) {
                // Skip invalid JSON
              }
            }
          }
        }
      }

      // Save final message
      addMessage(projectId, assistantMessage)

      // Auto-speak if TTS enabled
      if (ttsEnabled && assistantMessage.content && !assistantMessage.isCode) {
        speakText(assistantMessage.content, assistantMessage.id)
      }
    } catch (error: any) {
      if (error.name === "AbortError") {
        console.log("[v0] Request aborted by user")
      } else {
        console.error("[v0] Chat error:", error)
        alert("Failed to get response. Please try again.")
      }
    } finally {
      setIsLoading(false)
      abortControllerRef.current = null
    }
  }

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
      abortControllerRef.current = null
      setIsLoading(false)
    }
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    Array.from(files).forEach((file) => {
      if (file.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (e) => {
          const result = e.target?.result as string
          setImages((prev) => [...prev, result])
        }
        reader.readAsDataURL(file)
      }
    })
  }

  const handleVoiceInput = async () => {
    if (!("webkitSpeechRecognition" in window)) {
      alert("Speech recognition not supported in your browser")
      return
    }

    const recognition = new (window as any).webkitSpeechRecognition()
    recognition.continuous = false
    recognition.interimResults = false

    recognition.onstart = () => setIsRecording(true)
    recognition.onend = () => setIsRecording(false)

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript
      setInput((prev) => prev + " " + transcript)
    }

    recognition.start()
  }

  const speakText = (text: string, messageId: string) => {
    if ("speechSynthesis" in window) {
      // Cancel any ongoing speech
      window.speechSynthesis.cancel()

      // Remove code blocks from text
      const cleanText = text.replace(/```[\s\S]*?```/g, "").replace(/`[^`]*`/g, "")

      const utterance = new SpeechSynthesisUtterance(cleanText)
      utterance.lang = "en-US"
      utterance.rate = 1.0

      utterance.onstart = () => setSpeakingMessageId(messageId)
      utterance.onend = () => setSpeakingMessageId(null)
      utterance.onerror = () => setSpeakingMessageId(null)

      window.speechSynthesis.speak(utterance)
    }
  }

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code)
  }

  const extractCodeBlocks = (content: string) => {
    const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g
    const blocks: { language: string; code: string }[] = []
    let match

    while ((match = codeBlockRegex.exec(content)) !== null) {
      blocks.push({
        language: match[1] || "text",
        code: match[2].trim(),
      })
    }

    return blocks
  }

  const renderMessage = (message: Message) => {
    const isUser = message.role === "user"
    const codeBlocks = extractCodeBlocks(message.content)
    const textContent = message.content.replace(/```[\s\S]*?```/g, "").trim()

    return (
      <div key={message.id} className={cn("flex gap-4 mb-6", isUser && "flex-row-reverse")}>
        <Avatar className={cn("w-8 h-8 shrink-0", !isUser && "bg-gradient-to-br from-amber-500 to-yellow-600")}>
          {isUser ? (
            <>
              <AvatarImage src={getCurrentUser()?.avatar || "/placeholder.svg"} />
              <AvatarFallback className="bg-zinc-700 text-white">
                {getCurrentUser()?.username.charAt(0).toUpperCase()}
              </AvatarFallback>
            </>
          ) : (
            <Crown className="w-5 h-5 text-white" />
          )}
        </Avatar>

        <div className={cn("flex-1 space-y-2", isUser && "flex flex-col items-end")}>
          {message.images && message.images.length > 0 && (
            <div className="flex gap-2 flex-wrap">
              {message.images.map((img, idx) => (
                <img key={idx} src={img || "/placeholder.svg"} alt="Uploaded" className="max-w-xs rounded-lg" />
              ))}
            </div>
          )}

          {textContent && (
            <div
              className={cn(
                "rounded-2xl px-4 py-3 max-w-3xl",
                isUser ? "bg-gradient-to-r from-amber-500 to-yellow-600 text-white" : "bg-zinc-800/50 text-zinc-100",
              )}
            >
              <p className="whitespace-pre-wrap leading-relaxed">{textContent}</p>
            </div>
          )}

          {codeBlocks.map((block, idx) => (
            <div key={idx} className="max-w-3xl w-full">
              <div className="bg-zinc-900 rounded-lg border border-zinc-800 overflow-hidden">
                <div className="flex items-center justify-between px-4 py-2 bg-zinc-800/50 border-b border-zinc-700">
                  <span className="text-xs text-zinc-400 uppercase font-mono">{block.language}</span>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyCode(block.code)}
                    className="h-7 text-xs text-zinc-400 hover:text-white"
                  >
                    <Copy className="w-3 h-3 mr-1" />
                    {t.copyCode}
                  </Button>
                </div>
                <Textarea
                  value={block.code}
                  readOnly
                  className="font-mono text-sm bg-zinc-900 border-0 min-h-[200px] text-zinc-100 resize-none"
                />
              </div>
            </div>
          ))}

          {!isUser && !message.isCode && message.content && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => speakText(message.content, message.id)}
              disabled={speakingMessageId === message.id}
              className="text-zinc-400 hover:text-white"
            >
              <Volume2 className="w-4 h-4 mr-1" />
              {speakingMessageId === message.id ? t.speaking : "Speak"}
            </Button>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      {/* Messages */}
      <ScrollArea className="flex-1 px-4 py-6" ref={scrollRef}>
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-4 py-12">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center">
              <Crown className="w-8 h-8 text-white" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-bold text-white">{t.welcomeTitle}</h2>
              <p className="text-zinc-400 max-w-md">{t.welcomeSubtitle}</p>
            </div>
            <div className="flex flex-wrap gap-2 justify-center max-w-2xl">
              {["Generate Lua script", "Help with math homework", "Explain Delta Executor", "Create web page"].map(
                (prompt) => (
                  <Button
                    key={prompt}
                    variant="outline"
                    onClick={() => setInput(prompt)}
                    className="bg-zinc-800/50 border-zinc-700 hover:bg-zinc-700 text-zinc-300"
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    {prompt}
                  </Button>
                ),
              )}
            </div>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto">
            {messages.map(renderMessage)}
            {isLoading && (
              <div className="flex gap-4 mb-6">
                <Avatar className="w-8 h-8 bg-gradient-to-br from-amber-500 to-yellow-600">
                  <Crown className="w-5 h-5 text-white" />
                </Avatar>
                <div className="flex-1">
                  <div className="bg-zinc-800/50 rounded-2xl px-4 py-3 max-w-3xl">
                    <div className="flex gap-1">
                      <div
                        className="w-2 h-2 bg-amber-500 rounded-full animate-bounce"
                        style={{ animationDelay: "0ms" }}
                      />
                      <div
                        className="w-2 h-2 bg-amber-500 rounded-full animate-bounce"
                        style={{ animationDelay: "150ms" }}
                      />
                      <div
                        className="w-2 h-2 bg-amber-500 rounded-full animate-bounce"
                        style={{ animationDelay: "300ms" }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </ScrollArea>

      {/* Input Area */}
      <div className="border-t border-zinc-800 bg-zinc-900/50 backdrop-blur-xl p-4">
        <div className="max-w-4xl mx-auto space-y-3">
          {/* Image Previews */}
          {images.length > 0 && (
            <div className="flex gap-2 flex-wrap">
              {images.map((img, idx) => (
                <div key={idx} className="relative">
                  <img src={img || "/placeholder.svg"} alt="Preview" className="w-20 h-20 object-cover rounded-lg" />
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setImages((prev) => prev.filter((_, i) => i !== idx))}
                    className="absolute -top-2 -right-2 w-6 h-6 p-0 bg-red-500 hover:bg-red-600 text-white rounded-full"
                  >
                    ×
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Input */}
          <div className="flex gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleImageUpload}
              className="hidden"
            />

            <Button
              size="icon"
              variant="ghost"
              onClick={() => fileInputRef.current?.click()}
              disabled={isLoading}
              className="shrink-0 text-zinc-400 hover:text-white"
            >
              <ImageIcon className="w-5 h-5" />
            </Button>

            <Button
              size="icon"
              variant="ghost"
              onClick={handleVoiceInput}
              disabled={isLoading || isRecording}
              className={cn("shrink-0", isRecording ? "text-red-500" : "text-zinc-400 hover:text-white")}
            >
              <Mic className="w-5 h-5" />
            </Button>

            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault()
                  handleSend()
                }
              }}
              placeholder={t.typeMessage}
              disabled={isLoading}
              className="flex-1 min-h-[50px] max-h-[200px] bg-zinc-800/50 border-zinc-700 text-white resize-none"
            />

            {isLoading ? (
              <Button size="icon" onClick={handleStop} className="shrink-0 bg-red-500 hover:bg-red-600 text-white">
                <StopCircle className="w-5 h-5" />
              </Button>
            ) : (
              <Button
                size="icon"
                onClick={handleSend}
                disabled={!input.trim() && images.length === 0}
                className="shrink-0 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-600 hover:to-yellow-700 text-white"
              >
                <Send className="w-5 h-5" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
