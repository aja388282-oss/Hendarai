"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { User } from "@/types"
import { logout, updateUser, checkAndRefillLimit } from "@/lib/auth"
import { Crown, Settings, LogOut, Upload, Shield, Zap, Globe, Volume2, VolumeX, X } from "lucide-react"
import { cn } from "@/lib/utils"
import { Input } from "@/components/ui/input"

interface ProfilePanelProps {
  isOpen: boolean
  onToggle: () => void
  user: User
  onUserUpdate: (user: User) => void
  onLogout: () => void
  t: any
  language: "en" | "id"
  onLanguageChange: (lang: "en" | "id") => void
  ttsEnabled: boolean
  onTtsToggle: () => void
}

export function ProfilePanel({
  isOpen,
  onToggle,
  user,
  onUserUpdate,
  onLogout,
  t,
  language,
  onLanguageChange,
  ttsEnabled,
  onTtsToggle,
}: ProfilePanelProps) {
  const [isDeveloperPanelOpen, setIsDeveloperPanelOpen] = useState(false)
  const [searchEmail, setSearchEmail] = useState("")

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      const avatar = e.target?.result as string
      updateUser(user.id, { avatar })
      onUserUpdate({ ...user, avatar })
    }
    reader.readAsDataURL(file)
  }

  const handleUpgrade = () => {
    const phone = "083155374772"
    const message = encodeURIComponent("Hello, I want to upgrade my plan / limit")
    window.open(`https://wa.me/${phone}?text=${message}`, "_blank")
  }

  const getPlanBadgeColor = (plan: string) => {
    const colors: Record<string, string> = {
      free: "bg-zinc-700",
      junior: "bg-blue-600",
      basic: "bg-green-600",
      premium: "bg-purple-600",
      elite: "bg-orange-600",
      super: "bg-gradient-to-r from-amber-500 to-yellow-600",
    }
    return colors[plan] || "bg-zinc-700"
  }

  const updatedUser = checkAndRefillLimit(user)

  return (
    <>
      {/* Toggle Button */}
      <Button
        size="icon"
        variant="ghost"
        onClick={onToggle}
        className="fixed top-4 right-4 z-50 text-zinc-400 hover:text-white"
      >
        <Settings className="w-5 h-5" />
      </Button>

      {/* Panel */}
      <div
        className={cn(
          "fixed inset-y-0 right-0 z-40 w-80 bg-zinc-900/95 backdrop-blur-xl border-l border-zinc-800 transform transition-transform duration-300",
          isOpen ? "translate-x-0" : "translate-x-full",
        )}
      >
        <ScrollArea className="h-full">
          <div className="p-6 space-y-6">
            {/* Profile Header */}
            <div className="text-center space-y-4">
              <div className="relative inline-block">
                <Avatar className="w-24 h-24">
                  <AvatarImage src={updatedUser.avatar || "/placeholder.svg"} />
                  <AvatarFallback className="bg-gradient-to-br from-amber-500 to-yellow-600 text-white text-2xl">
                    {updatedUser.username.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <label className="absolute bottom-0 right-0 w-8 h-8 bg-zinc-800 rounded-full flex items-center justify-center cursor-pointer hover:bg-zinc-700 transition-colors">
                  <Upload className="w-4 h-4 text-zinc-400" />
                  <input type="file" accept="image/*" onChange={handleAvatarUpload} className="hidden" />
                </label>
              </div>

              <div className="space-y-2">
                <h3 className="text-xl font-bold text-white">{updatedUser.username}</h3>
                <p className="text-sm text-zinc-400">{updatedUser.email}</p>
              </div>

              {/* Badges */}
              <div className="flex gap-2 justify-center flex-wrap">
                <Badge className={cn("text-white", getPlanBadgeColor(updatedUser.plan))}>
                  <Crown className="w-3 h-3 mr-1" />
                  {t[updatedUser.plan]}
                </Badge>
                {(updatedUser.role === "developer" || updatedUser.role === "owner") && (
                  <Badge className="bg-blue-600 text-white">
                    <Shield className="w-3 h-3 mr-1" />
                    {t[updatedUser.role]}
                  </Badge>
                )}
              </div>
            </div>

            {/* Message Limit */}
            <div className="bg-zinc-800/50 rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-zinc-400">{t.messagesLeft}</span>
                <span className="text-lg font-bold text-white">
                  {updatedUser.messageLimit === -1 ? t.unlimited : updatedUser.messageLimit}
                </span>
              </div>

              {updatedUser.messageLimit !== -1 && updatedUser.messageLimit < 5 && (
                <div className="space-y-2">
                  <div className="w-full h-2 bg-zinc-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-amber-500 to-yellow-600 transition-all"
                      style={{ width: `${(updatedUser.messageLimit / 10) * 100}%` }}
                    />
                  </div>
                  {updatedUser.messageLimit === 0 && <p className="text-xs text-zinc-400">{t.waitForRefill}</p>}
                </div>
              )}

              <Button
                onClick={handleUpgrade}
                className="w-full bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-600 hover:to-yellow-700 text-white font-semibold"
              >
                <Zap className="w-4 h-4 mr-2" />
                {t.upgradePlan}
              </Button>
            </div>

            {/* Settings */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-zinc-400 uppercase">{t.settings}</h4>

              {/* Language Toggle */}
              <div className="bg-zinc-800/50 rounded-lg p-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-zinc-400" />
                  <span className="text-sm text-zinc-300">Language</span>
                </div>
                <div className="flex gap-1">
                  <Button
                    size="sm"
                    variant={language === "en" ? "default" : "ghost"}
                    onClick={() => onLanguageChange("en")}
                    className={cn(
                      "h-7 px-3 text-xs",
                      language === "en" && "bg-amber-500 hover:bg-amber-600 text-white",
                    )}
                  >
                    EN
                  </Button>
                  <Button
                    size="sm"
                    variant={language === "id" ? "default" : "ghost"}
                    onClick={() => onLanguageChange("id")}
                    className={cn(
                      "h-7 px-3 text-xs",
                      language === "id" && "bg-amber-500 hover:bg-amber-600 text-white",
                    )}
                  >
                    ID
                  </Button>
                </div>
              </div>

              {/* TTS Toggle */}
              <button
                onClick={onTtsToggle}
                className="w-full bg-zinc-800/50 rounded-lg p-3 flex items-center justify-between hover:bg-zinc-800 transition-colors"
              >
                <div className="flex items-center gap-2">
                  {ttsEnabled ? (
                    <Volume2 className="w-4 h-4 text-amber-500" />
                  ) : (
                    <VolumeX className="w-4 h-4 text-zinc-400" />
                  )}
                  <span className="text-sm text-zinc-300">Text-to-Speech</span>
                </div>
                <div
                  className={cn(
                    "w-10 h-6 rounded-full transition-colors relative",
                    ttsEnabled ? "bg-amber-500" : "bg-zinc-700",
                  )}
                >
                  <div
                    className={cn(
                      "absolute top-1 w-4 h-4 bg-white rounded-full transition-transform",
                      ttsEnabled ? "right-1" : "left-1",
                    )}
                  />
                </div>
              </button>
            </div>

            {/* Developer Panel */}
            {(updatedUser.role === "developer" || updatedUser.role === "owner") && (
              <Button
                onClick={() => setIsDeveloperPanelOpen(true)}
                variant="outline"
                className="w-full border-zinc-700 hover:bg-zinc-800 text-zinc-300"
              >
                <Shield className="w-4 h-4 mr-2" />
                {t.developer} Panel
              </Button>
            )}

            {/* Logout */}
            <Button
              onClick={() => {
                logout()
                onLogout()
              }}
              variant="outline"
              className="w-full border-red-500/50 hover:bg-red-500/10 text-red-400"
            >
              <LogOut className="w-4 h-4 mr-2" />
              {t.logout}
            </Button>
          </div>
        </ScrollArea>
      </div>

      {/* Overlay */}
      {isOpen && <div onClick={onToggle} className="fixed inset-0 z-30 bg-black/50 backdrop-blur-sm" />}

      {/* Developer Panel Modal */}
      {isDeveloperPanelOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-zinc-900 rounded-xl border border-zinc-800 w-full max-w-2xl max-h-[90vh] overflow-hidden">
            <div className="p-6 border-b border-zinc-800 flex items-center justify-between">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-500" />
                Developer Panel
              </h2>
              <Button size="icon" variant="ghost" onClick={() => setIsDeveloperPanelOpen(false)}>
                <X className="w-5 h-5" />
              </Button>
            </div>

            <ScrollArea className="p-6 max-h-[calc(90vh-80px)]">
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">{t.userManagement}</h3>
                  <div className="flex gap-2">
                    <Input
                      placeholder={t.searchUser}
                      value={searchEmail}
                      onChange={(e) => setSearchEmail(e.target.value)}
                      className="flex-1 bg-zinc-800 border-zinc-700 text-white"
                    />
                    <Button
                      onClick={() => {
                        const users = JSON.parse(localStorage.getItem("hendar_hub_users") || "[]")
                        const user = users.find((u: User) => u.email === searchEmail)
                        setIsDeveloperPanelOpen(false)
                        if (user) {
                          alert(`User found: ${user.username}`)
                        } else {
                          alert("User not found")
                        }
                      }}
                      className="bg-amber-500 hover:bg-amber-600"
                    >
                      Search
                    </Button>
                  </div>
                </div>
              </div>
            </ScrollArea>
          </div>
        </div>
      )}
    </>
  )
}
