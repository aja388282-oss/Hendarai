"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Input } from "@/components/ui/input"
import { PanelLeft, Plus, MessageSquare, Trash2, Edit2, Check, X } from "lucide-react"
import type { Project } from "@/types"
import { deleteProject, saveProject } from "@/lib/projects"
import { cn } from "@/lib/utils"

interface SidebarProps {
  isOpen: boolean
  onToggle: () => void
  projects: Project[]
  activeProjectId: string | null
  onProjectSelect: (projectId: string) => void
  onNewProject: () => void
  t: any
}

export function Sidebar({
  isOpen,
  onToggle,
  projects,
  activeProjectId,
  onProjectSelect,
  onNewProject,
  t,
}: SidebarProps) {
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editName, setEditName] = useState("")

  const handleRename = (project: Project) => {
    if (editName.trim()) {
      project.name = editName
      saveProject(project)
    }
    setEditingId(null)
    setEditName("")
  }

  const handleDelete = (projectId: string) => {
    if (confirm("Delete this chat?")) {
      deleteProject(projectId)
      if (activeProjectId === projectId && projects.length > 1) {
        const otherProject = projects.find((p) => p.id !== projectId)
        if (otherProject) onProjectSelect(otherProject.id)
      }
    }
  }

  return (
    <>
      {/* Toggle Button */}
      <Button
        size="icon"
        variant="ghost"
        onClick={onToggle}
        className="fixed top-4 left-4 z-50 text-zinc-400 hover:text-white"
      >
        <PanelLeft className="w-5 h-5" />
      </Button>

      {/* Sidebar */}
      <div
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-72 bg-zinc-900/95 backdrop-blur-xl border-r border-zinc-800 transform transition-transform duration-300",
          isOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex flex-col h-full pt-16 pb-4">
          {/* New Chat Button */}
          <div className="px-4 mb-4">
            <Button
              onClick={onNewProject}
              className="w-full bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-600 hover:to-yellow-700 text-white font-semibold"
            >
              <Plus className="w-4 h-4 mr-2" />
              {t.newChat}
            </Button>
          </div>

          {/* Projects List */}
          <ScrollArea className="flex-1 px-2">
            <div className="space-y-1">
              {projects.map((project) => (
                <div
                  key={project.id}
                  className={cn(
                    "group relative rounded-lg transition-colors",
                    project.id === activeProjectId ? "bg-zinc-800" : "hover:bg-zinc-800/50",
                  )}
                >
                  {editingId === project.id ? (
                    <div className="flex items-center gap-1 p-2">
                      <Input
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") handleRename(project)
                          if (e.key === "Escape") setEditingId(null)
                        }}
                        className="h-8 bg-zinc-900 border-zinc-700 text-white text-sm"
                        autoFocus
                      />
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => handleRename(project)}
                        className="h-8 w-8 shrink-0"
                      >
                        <Check className="w-4 h-4 text-green-500" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => setEditingId(null)}
                        className="h-8 w-8 shrink-0"
                      >
                        <X className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  ) : (
                    <button
                      onClick={() => onProjectSelect(project.id)}
                      className="w-full flex items-center gap-3 p-3 text-left"
                    >
                      <MessageSquare className="w-4 h-4 shrink-0 text-zinc-400" />
                      <span className="flex-1 text-sm text-zinc-300 truncate">{project.name}</span>
                      <div className="hidden group-hover:flex items-center gap-1 shrink-0">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation()
                            setEditingId(project.id)
                            setEditName(project.name)
                          }}
                          className="h-7 w-7"
                        >
                          <Edit2 className="w-3 h-3 text-zinc-400" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleDelete(project.id)
                          }}
                          className="h-7 w-7"
                        >
                          <Trash2 className="w-3 h-3 text-red-400" />
                        </Button>
                      </div>
                    </button>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      </div>

      {/* Overlay */}
      {isOpen && <div onClick={onToggle} className="fixed inset-0 z-30 bg-black/50 backdrop-blur-sm" />}
    </>
  )
}
